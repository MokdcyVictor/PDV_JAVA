/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.discipulosdofabrizio.app;

import javax.swing.*;

/**
 *
 * @author cardlucas1
 */
public class Main {
    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Oi!");
    }
}
